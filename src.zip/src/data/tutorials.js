const tutorials = [
  {
    title: "React Basics",
    description: "Intro to React",
    author: "C",
    rating: 4,
    image: "https://images.pexels.com/photos/1089438/pexels-photo-1089438.jpeg"
  },
  {
    title: "Semantic UI",
    description: "Using Semantic UI intoduction",
    author: "D",
    rating: 5,
    image: "https://images.pexels.com/photos/196645/pexels-photo-196645.jpeg"
  }
];

export default tutorials;