const articles = [
  {
    title: "Visualization",
    description: "Visualization",
    author: "A",
    rating: 5,
    image: "https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg"
  },
  {
    title: "Node.js introduction",
    description: "Learn basic using of NodeJS",
    author: "B",
    rating: 4,
    image: "https://images.pexels.com/photos/177598/pexels-photo-177598.jpeg"
  }
];

export default articles;