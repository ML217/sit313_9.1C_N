import React from 'react';

const Header = () => (
  <div style={{ backgroundColor: '#eee', padding: '1em', display: 'flex', justifyContent: 'space-between' }}>
    <div><strong>DEV@Deakin</strong></div>
    <input type="text" placeholder="Search..." style={{ flex: 1, margin: '0 1em' }} />
    <div>
      <button>Post</button>
      <button>Login</button>
    </div>
  </div>
);
export default Header;