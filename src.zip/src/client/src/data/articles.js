const articles = [
  {
    name: 'Visualization',
    description: 'Visualization',
    rating: 5,
    author: 'A',
    image: 'https://picsum.photos/200?random=1'
  },
  {
    name: 'Node.js introduction',
    description: 'e.g., NodeJS',
    rating: 4,
    author: 'B',
    image: 'https://picsum.photos/200?random=2'
  },
  {
    name: 'Using React Hooks',
    description: 'e.g., React Hooks',
    rating: 3,
    author: 'C',
    image: 'https://picsum.photos/200?random=3'
  }
];
export default articles;