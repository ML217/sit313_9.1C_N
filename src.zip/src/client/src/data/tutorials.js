const tutorials = [
  {
    name: 'JSDoc Intro',
    description: 'e.g., JSDoc',
    rating: 5,
    username: 'dev_jane',
    image: 'https://picsum.photos/200?random=4'
  },
  {
    name: 'React Router Guide',
    description: 'React Router',
    rating: 5,
    username: 'dev_john',
    image: 'https://picsum.photos/200?random=5'
  },
  {
    name: 'Express Basics',
    description: 'e.g., Express',
    rating: 4.9,
    username: 'dev_alice',
    image: 'https://picsum.photos/200?random=6'
  }
];
export default tutorials;