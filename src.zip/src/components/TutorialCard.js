import React from 'react';
import { Card, Icon } from 'semantic-ui-react';

const TutorialCard = ({ tutorial }) => (
  <Card
    image={tutorial.image}
    header={tutorial.title}
    meta={tutorial.description}
    description={`by ${tutorial.author}`}
    extra={<><Icon name='star' color='yellow' /> {tutorial.rating}</>}
  />
);
export default TutorialCard;